package com.awc.paymentbatch.paymentbatch;

import java.util.List;
import org.springframework.batch.core.ItemWriteListener;

import com.awc.domain.Customer;

public class CustomItemWriterListener implements ItemWriteListener<Customer> {

	@Override
	public void beforeWrite(List<? extends Customer> items) {
		System.out.println("ItemWriteListener - beforeWrite");
	}

	@Override
	public void afterWrite(List<? extends Customer> items) {
		System.out.println("ItemWriteListener - afterWrite");
	}

	@Override
	public void onWriteError(Exception exception, List<? extends Customer> items) {
		System.out.println("ItemWriteListener - onWriteError");
	}

}