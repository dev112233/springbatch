
package com.awc.paymentbatch.paymentbatch;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.integration.async.AsyncItemProcessor;
import org.springframework.batch.integration.async.AsyncItemWriter;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.support.H2PagingQueryProvider;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.interceptor.TransactionProxyFactoryBean;

import com.awc.domain.Customer;
import com.awc.domain.CustomerRowMapper;


@Configuration
@Import({ ServletConfiguration.class, WebappConfiguration.class, AWCBatchController.class })
//@EnableBatchProcessing

public class JobConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

    @Autowired
	SimpleJobLauncher jobLauncher;
    
	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public DataSource dataSource;
	
	@Autowired
	@Qualifier("batchTaskExecutor")
	TaskExecutor executor;
	 private static final String QUERY_FIND_CUSTOMER =
	            "SELECT " +
	                "id, firstName, lastName " +
	            "FROM customer where PROCESSED_FLAG is null " +
	            "ORDER BY id";
	int attemptCount=0;
	int count =0;

	@Bean
	public JobRepository createJobRepository(PlatformTransactionManager manager) throws Exception {
	    JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
	    factory.setDataSource(dataSource);
	    factory.setTransactionManager(manager);
	    factory.setIsolationLevelForCreate("ISOLATION_SERIALIZABLE");
	    factory.setTablePrefix("BATCH_");
	    factory.setMaxVarCharLength(1000);
	    return factory.getObject();
	}
	
	@Bean
	public JobBuilderFactory jobBuilderFactory(JobRepository jobRepository) {
		return new JobBuilderFactory(jobRepository);
	}


	@Bean
	public StepBuilderFactory stepBuilderFactory(JobRepository jobRepository,
			PlatformTransactionManager transactionManager) {
		return new StepBuilderFactory(jobRepository, transactionManager);
	}
	
	@Bean
	public SimpleJobOperator jobOperator(JobExplorer jobExplorer, JobRepository jobRepository,
			JobRegistry jobRegistry) {
		SimpleJobOperator jobOperator = new SimpleJobOperator();
		jobOperator.setJobExplorer(jobExplorer);
		jobOperator.setJobRepository(jobRepository);
		jobOperator.setJobRegistry(jobRegistry);
		jobOperator.setJobLauncher(jobLauncher);
		return jobOperator;
	}
	/*@Bean
	public JobLauncher jobLauncher() {
	        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
	        jobLauncher.setJobRepository(jobRepo);
	       // jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
	        //jobLauncher.afterPropertiesSet();
	        return jobLauncher;
	}*/
/*	@Bean
	@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
	public synchronized ItemStreamReader<Customer> pagingItemReader() {
		System.out.println("*********************Reader****");

		JdbcPagingItemReader<Customer> reader = new JdbcPagingItemReader<>();
		

		reader.setDataSource(this.dataSource);
		reader.setFetchSize(10);
		reader.setRowMapper(new CustomerRowMapper());

		H2PagingQueryProvider queryProvider = new H2PagingQueryProvider();
		queryProvider.setSelectClause("id, firstName, lastName");
		queryProvider.setFromClause("from customer");
		Map<String, Order> sortKeys = new HashMap<>(1);

		sortKeys.put("id", Order.ASCENDING);

		queryProvider.setSortKeys(sortKeys);

		reader.setQueryProvider(queryProvider);
		System.out.println("size" + reader.toString());
		return reader;
	}*/
	//must have a order by clause required for restartability ****IMP***so that it picks up where it left
	@Bean
	public  ItemStreamReader<Customer> pagingItemReader() {// pagingitem reader for restartability
		/*System.out.println("*********************Reader****");

		JdbcPagingItemReader<Customer> reader = new JdbcPagingItemReader<>();
		

		reader.setDataSource(this.dataSource);
		reader.setFetchSize(10);
		reader.setRowMapper(new CustomerRowMapper());

		H2PagingQueryProvider queryProvider = new H2PagingQueryProvider();
		queryProvider.setSelectClause("id, firstName, lastName");
		queryProvider.setFromClause("from customer");
		Map<String, Order> sortKeys = new HashMap<>(1);

		sortKeys.put("id", Order.ASCENDING);

		queryProvider.setSortKeys(sortKeys);// required for thread safety.. keep track of last key(unique) that was read.

		reader.setQueryProvider(queryProvider);
		System.out.println("size" + reader.toString());*/
		JdbcCursorItemReader<Customer> databaseReader = new JdbcCursorItemReader<>();
		 
        databaseReader.setDataSource(dataSource);
        databaseReader.setSql(QUERY_FIND_CUSTOMER);
        databaseReader.setRowMapper(new BeanPropertyRowMapper<>(Customer.class));
 
		return databaseReader;
	}
	private int attemptCountProcess = 0;

	@Bean
	public ItemProcessor itemProcessor() {
		return new ItemProcessor<Customer, Customer>() {

			@Override
			public Customer process(Customer item) throws Exception {
				try {
					System.out
							.println(Thread.currentThread().getName() + "*********************Entry-Processor****" + item);
					if(!item.isProcessed()) {
						Thread.sleep(new Random().nextInt(1000));
						if (item.getId() == 12 /*&& attemptCountProcess<5*/) {
							System.out.println("----------------not this time----------------  ");
							attemptCountProcess++;
							throw new RetryableException();
						}
/*		if (item.getId() == 7) {
							throw new CustomException();
						}
						if (item.getId() == 15) {
							throw new CustomException();
						}*/
						System.out.println(Thread.currentThread().getName() + "*********************Exit-Processor****" + item);
						item.setProcessed(true);
					}else {
						System.out.println("Item -"+item.getId()+"Already processed.. so not processing again");
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					item.setProcessed(false);
				}
				return new Customer(item.getId(), item.getFirstName().toUpperCase(), item.getLastName().toUpperCase());
			}
		};
	}

	@Bean
	public AsyncItemProcessor asyncItemProcessor() throws Exception {
		System.out.println("*********************AyncProcessor****");
		AsyncItemProcessor<Customer, Customer> asyncItemProcessor = new AsyncItemProcessor();
		asyncItemProcessor.setDelegate(itemProcessor());
		asyncItemProcessor.setTaskExecutor(executor);
		asyncItemProcessor.afterPropertiesSet();

		return asyncItemProcessor;
	}
	
	@Bean
	@Qualifier("batchTaskExecutor")
	public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
		exec.setCorePoolSize(2);
		exec.setMaxPoolSize(3);
		exec.setQueueCapacity(10);
		return exec;
		
	}
	@Bean
	public CustomItemWriter writer() {
		return new CustomItemWriter();
	}


	@Bean
	public JdbcBatchItemWriter customerItemWriter() {
		JdbcBatchItemWriter<Customer> itemWriter = new JdbcBatchItemWriter<>();
		count++;
		System.out.println("In writer################################################################>"+count);
		if(count==2) {
			//throw new RuntimeException();
		}
		itemWriter.setDataSource(this.dataSource);
		itemWriter.setSql("update customer set retry_count=retry_count+1,PROCESSED_FLAG='Y' where id=:id ");
		itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider());
		itemWriter.afterPropertiesSet();

		return itemWriter;
	}

	@Bean
	public AsyncItemWriter asyncItemWriter() throws Exception {
		AsyncItemWriter<Customer> asyncItemWriter = new AsyncItemWriter<>();

		asyncItemWriter.setDelegate(customerItemWriter());
		asyncItemWriter.afterPropertiesSet();

		return asyncItemWriter;
	}
	@Bean
	//@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
	public Step paymentBatchstep() throws Exception {
		return stepBuilderFactory.get("step")
				.chunk(4)
				.reader(pagingItemReader())
				//.processor(asyncItemProcessor())
				.processor(itemProcessor())
				//.writer(asyncItemWriter())
				.writer(customerItemWriter())
				.faultTolerant()
				.retry(RetryableException.class)//--retry--> service unavailable
				.retryLimit(6) // means do not proceed with batch if the retry limit is reached  
				//.skip(SkippableException.class) //--skip--> bad data
				//.skipLimit(3)   // means do not proceed with batch if the skip limit is reached         
				//.listener(new CustomItemWriterListener())
				//.listener(new CustomItemReaderListener())
				//.listener(new CustomItemProcessListener())
				//.taskExecutor(executor)
				.build();
	}
	@Bean
	@Qualifier("paymentBatch")
	public Job job() throws Exception {
		//return jobs.get("paymentBatchJob").incrementer(new RunIdIncrementer()).start(paymentBatch()).build();
		
		return jobBuilderFactory.get("paymentBatchJob").start(paymentBatchstep()).build();

	}
}
