
package com.awc.paymentbatch.paymentbatch;

public class RetryableException extends Exception {

	public RetryableException() {
		super();
	}

	public RetryableException(String msg) {
		super(msg);
	}
}
