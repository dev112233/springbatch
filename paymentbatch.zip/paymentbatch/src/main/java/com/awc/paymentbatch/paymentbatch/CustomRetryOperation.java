package com.awc.paymentbatch.paymentbatch;

import org.springframework.retry.ExhaustedRetryException;
import org.springframework.retry.RecoveryCallback;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryOperations;
import org.springframework.retry.RetryState;

public class CustomRetryOperation implements RetryOperations  {
	
	@Override
	public <T, E extends Throwable> T execute(RetryCallback<T, E> retryCallback) throws E {
		//System.out.println(retryCallback.doWithRetry(context));
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T, E extends Throwable> T execute(RetryCallback<T, E> retryCallback, RecoveryCallback<T> recoveryCallback)
			throws E {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T, E extends Throwable> T execute(RetryCallback<T, E> retryCallback, RetryState retryState)
			throws E, ExhaustedRetryException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T, E extends Throwable> T execute(RetryCallback<T, E> retryCallback, RecoveryCallback<T> recoveryCallback,
			RetryState retryState) throws E {
		// TODO Auto-generated method stub
		return null;
	}

}
