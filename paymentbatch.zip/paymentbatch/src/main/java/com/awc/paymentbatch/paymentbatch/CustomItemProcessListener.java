package com.awc.paymentbatch.paymentbatch;

import org.springframework.batch.core.ItemProcessListener;

import com.awc.domain.Customer;

public class CustomItemProcessListener implements ItemProcessListener {

	@Override
	public void beforeProcess(Object item) {
		// TODO Auto-generated method stub
		System.out.println("Before Processing :::::"+item);
		
	}

	@Override
	public void afterProcess(Object item, Object result) {
		System.out.println("after Processing :::::"+item);
		
	}

	@Override
	public void onProcessError(Object item, Exception e) {
		System.out.println("Error while Processing :::::"+item);
		
	}

}
