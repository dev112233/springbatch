
package com.awc.paymentbatch.paymentbatch;

public class CustomException extends Exception {

	public CustomException() {
		super();
	}

	public CustomException(String msg) {
		super(msg);
	}
}
