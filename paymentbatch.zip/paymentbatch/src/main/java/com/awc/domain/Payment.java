package com.awc.domain;

public class Payment {
    private String cardNumber;
    private String amount;
    private String status;

    public Payment() {

    }

    public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Payment(String amount, String cardNumber) {
        this.amount = amount;
        this.cardNumber = cardNumber;
    }

    
   

    @Override
    public String toString() {
        return "amount: " + amount + ", card Number: " + cardNumber;
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}